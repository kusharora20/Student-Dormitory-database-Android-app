package tech.ceece.hw_1_214;

public class FullFloorException extends Exception {
    public FullFloorException(String message){
        super(message);
    }
}

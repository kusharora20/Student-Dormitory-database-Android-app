package tech.ceece.hw_1_214;


public class EmptyFloorException extends Exception{
    public EmptyFloorException(String message){
        super(message);
    }
}

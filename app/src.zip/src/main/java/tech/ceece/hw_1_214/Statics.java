package tech.ceece.hw_1_214;

/**
 * Created by yashj on 2/6/2017.
 */
public class Statics {
    public static Floor toFloor; //Object reference
}
